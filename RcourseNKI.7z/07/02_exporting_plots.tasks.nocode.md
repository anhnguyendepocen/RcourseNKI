---
title: "Exporting plots"
date: "09 juni 2020"
---

# Exporting plots

## Exporting some simple plots

We will make some plots for the USJudgeRatings data.

- Make a barplot for the second column of the USJudgeratings data. Add the names of the judges at the x-axis in a readable way. You can use `barplot` or `ggplot` as you choose. Add the name of the column as a title.



- Make the same plot for the third column.



- make a pdf file that has the 11 plots for the 11 columns (not using the first) on separate pages.



- 
